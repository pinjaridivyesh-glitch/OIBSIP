# OASIS INFOBYTE INTERNSHIP - LEVEL 1 (WEB DEVELOPMENT & DESIGNING)

![Oasis Infobyte](https://img.shields.io/badge/OASIS_INFOBYTE-Level_1_Internship-blue?style=for-the-badge)
![Status](https://img.shields.io/badge/Status-All_3_Tasks_Completed-brightgreen?style=for-the-badge)
![Domain](https://img.shields.io/badge/Domain-Web_Development_%26_Designing-purple?style=for-the-badge)

Welcome to the complete repository for the **Oasis Infobyte (OIBSIP) Web Development and Designing Level 1 Internship Projects**.

This repository houses all 3 assigned tasks, built strictly adhering to the OASIS rules with clean semantic code, modern responsive design, interactive animations, and comprehensive documentation.

---

## 🗂️ Project Structure

```
OIBSIP/
├── WebDev-L1-LandingPage/        # TASK 1: Product Landing Page (AURA PRO X Headphones)
│   ├── index.html                # Semantic HTML5 layout
│   ├── style.css                 # Responsive CSS3 styling & animations
│   └── README.md                 # Detailed documentation for Task 1
│
├── WebDev-L1-Portfolio/          # TASK 2: Personal Portfolio (Divyesh - B.Tech AIML)
│   ├── index.html                # Semantic HTML5 structure
│   ├── style.css                 # Cyber-developer dark styling & layout
│   ├── script.js                 # Smooth scroll, active nav, mobile drawer & form
│   └── README.md                 # Detailed documentation for Task 2
│
└── WebDev-L1-TempConverter/      # TASK 3: Temperature Converter Website
    ├── index.html                # Application layout & UI controls
    ├── style.css                 # Glassmorphic UI & thermal indicator
    ├── script.js                 # Validation, formula arithmetic & edge cases
    └── README.md                 # Detailed documentation for Task 3
```

---

## 📋 Task Summaries

### 🎯 Task 1: AURA PRO X - Product Landing Page
- **Path**: `OIBSIP/WebDev-L1-LandingPage/`
- **Objective**: Visually polished static product landing page for flagship wireless headphones.
- **Tech Stack**: Pure HTML5, CSS3.
- **Key Features**:
  - Sticky glassmorphic navbar with 6 navigation targets and pure CSS mobile menu.
  - Hero section with live pulse badge, custom SVG headphones illustration, and floating spec tags.
  - 6-card feature grid with custom icons and accent glow effects.
  - Hardware engineering specifications table and comparison metrics.
  - Critical acclaim testimonials from industry audio engineers.
  - Pre-order pricing card with benefit checklist and customer inquiry form.

### 🎯 Task 2: Personal Developer Portfolio
- **Path**: `OIBSIP/WebDev-L1-Portfolio/`
- **Objective**: Personal Portfolio website for B.Tech AIML student.
- **Tech Stack**: HTML5, CSS3, Vanilla JavaScript.
- **Key Features**:
  - Hero with name (*Divyesh*), role (*Web Developer | B.Tech AIML*), availability indicator, and geometric code avatar.
  - About Me: *"I'm Divyesh, B.Tech AIML student passionate about AI/ML and Web Development. Intern at OASIS INFOBYTE."*
  - Skills grid covering HTML5, CSS3, JavaScript (ES6+), Python, Git & GitHub, and Responsive UI.
  - Featured project cards linking to live previews of Task 1 and Task 3.
  - Interactive contact channels (Email, LinkedIn, GitHub) + functional validation form.

### 🎯 Task 3: Precision Temperature Converter
- **Path**: `OIBSIP/WebDev-L1-TempConverter/`
- **Objective**: High-accuracy temperature converter with real-time feedback and edge-case handling.
- **Tech Stack**: HTML5, CSS3, Vanilla JavaScript.
- **Key Features**:
  - Strict input validation rejecting empty, text, or malformed inputs with instant alert boxes.
  - **Absolute Zero Physical Guardrail**: Flags inputs below -273.15°C / -459.67°F / 0K with a dedicated alert.
  - Simultaneous conversion to Celsius (°C), Fahrenheit (°F), and Kelvin (K).
  - Dynamic mathematical formula substitution breakdown card.
  - Thermal range visualizer (from Absolute Zero to Boiling/Extreme).
  - Quick-preset chips (Freezing, Body Temp, Boiling, Absolute Zero).

---

## ⚡ How to Run Locally

You can run any of the tasks without any build tools or package managers:

1. Clone this repository:
   ```bash
   git clone https://github.com/pinjaridivyesh-glitch/OIBSIP.git
   cd OIBSIP
   ```
2. Navigate into any task folder:
   - For Landing Page: `cd WebDev-L1-LandingPage`
   - For Portfolio: `cd WebDev-L1-Portfolio`
   - For Temp Converter: `cd WebDev-L1-TempConverter`
3. Open `index.html` in your favorite web browser (Chrome, Edge, Firefox, Brave).

---

## 👤 Author Information

- **Intern Name**: Divyesh - B.Tech AIML Student
- **About Me**: I'm Divyesh, B.Tech AIML student passionate about AI/ML and Web Development. Intern at OASIS INFOBYTE.
- **GitHub**: [https://github.com/pinjaridivyesh-glitch](https://github.com/pinjaridivyesh-glitch)
- **Internship Program**: Oasis Infobyte Web Development & Designing Internship (OIBSIP)
- **Level**: Level 1
- **Domain**: Web Development
